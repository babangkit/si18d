<?php
 for ($a=5; $a>=1; $a--) {
	for($b=5; $b>=$a; $b--) {
		echo $b; 
	}echo "<br>";
}
for ($a=2; $a<=5; $a++) {
	for ($b=5; $b>=$a; $b--) {
		echo $b;
	}echo "<br>";
} 	   
?>


Tri Suci Desiana (18.12.0148)