<html>
<head>
	<title> Tugas PemrogramanWeb </title>
</head>
<body>

<?php
	for ($i = 5; $i >=1; $i--) {
		for ($j = 5; $j >= $i; $j--){
			echo $j;
		}
		echo "<br>";
	}

	for ($i = 2; $i <=5; $i++) {
		for ($j = 5; $j >= $i; $j--){
			echo $j;
		}
		echo "<br>";
	}
?>

<p>Nama : Junistyan Ginka Monteverdi</p>
<p>NIM : 18.12.0133</p>
</body>
</html>