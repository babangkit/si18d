<!DOCTYPE html>
<html>
<head>
	<title>TUGAS PERULANGAN PEMOGRAMAN WEB</title>
</head>
<body>
<?php
for ($a=5; $a>=1; $a--){
    for ($b=5; $b>=$a; $b--){
          echo $b;
     }echo "<br>";
}
?>
<?php
for ($a=1; $a<=5; $a++){
    for ($b=5; $b>=$a; $b--){
        echo $b;
    }echo "<br>";
}
?>
<br>
Nama  : Reza Kusuma Wardana <br>
Kelas : SI 18 D <br>
NIM	  : 18.12.0127</br>
</body>
</html>