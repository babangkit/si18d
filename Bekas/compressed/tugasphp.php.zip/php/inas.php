<!DOCTYPE html>
<html>
<head>
	<title>Tugas Pemrograman web</title>
</head>
<body>
<?php
for ($a=5; $a>=1; $a--){
    for ($b=5; $b>=$a; $b--){
          echo $b;
     }echo "<br>";
}
?>
<?php
for ($a=1; $a<=5; $a++){
    for ($b=5; $b>=$a; $b--){
        echo $b;
    }echo "<br>";
}
?>
<br>
Nama	: Inas Nada Wardhani<br>
NIM		: 18.12.0145</br>
</body>
</html>