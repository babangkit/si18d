<?php
    /* Nama = Maharani Kusuma Dewi
	   NIM  = 18.12.0132
	   Kelas= SI18D */
	   
for ($i=5; $i>=1; $i--) {
	for($j=5; $j>=$i; $i--) {
		echo $j; 
		}echo "<br>";
}
for ($i=2; $i<=5; $i++) {
	for ($j=5; $j>=$i; $j--) {
		echo $j;
	}echo "<br>";
}    
?>