<!DOCTYPE html>
<html>
<head>
	<title>Tugas Pemrograman Web</title>
</head>
<body>
<?php
for ($i=5;$i>=1;$i--){
	for ($j=5;$j>=$i;$j--){ 
	 	echo $j;
	 }echo"<br>";
}
?>
<?php
for ($i=1;$i<=5;$i++){
    for ($j=5;$j>=$i;$j--){
        echo $j;
    }echo "<br>";
}
?>
<br>
Nama	: Tabah Prasetiyo<br>
NIM		: 18.12.0142</br>
</body>
</html>