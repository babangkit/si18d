<?php //*Meta Damayanti_18.12.0138*//
	for ($m=5; $m>0;$m--) {
		for ($d=5;$d>=$m;$d--) {
		echo $d;
		}
		echo "<br>";
}

for ($m=2; $m<=5; $m++) {
	for ($t=5; $t>=$m; $t--) {
		echo $t;
		}
		echo "<br>";
	} //*Meta Damayanti_18.12.0138*//
?> 