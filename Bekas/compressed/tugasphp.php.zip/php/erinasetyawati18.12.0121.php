<?php
	for ($i=5; $i>=1; $i--){
		for ($j=5; $j>=$i; $j--){
          echo $j;
    }echo "<br>";
}
	for ($i=1; $i<=5; $i++){
		for ($j=5; $j>=$i; $j--){
        echo $j;
    }echo "<br>";
?>
