<?php
for ($u=5; $u>=1; $u--) {
	for($t=5; $t>=$u; $t--) {
		echo $t; 
	}echo "<br>";
}
for ($u=2; $u<=5; $u++) {
	for ($t=5; $t>=$u; $t--) {
		echo $t;
	}echo "<br>";
}    
?>


Maharani Kusuma Dewi_18.12.0132