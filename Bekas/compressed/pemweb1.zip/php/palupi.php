<?php
for ($i=5;$i>=2;$i--){
      for ($j=5; $j>=$i; $j--){
          echo $j;
      }
      echo "<br>";
}
for($r=1; $r<=6; $r++){
	for($s=5; $s>=$r; $s--){
		echo $s;
	};
	echo "<br>";
}//AUTHOR: PALUPI PANDANARUM-18.12.0119
	echo "PALUPI PANDANARUM-18.12.0119"
?>
