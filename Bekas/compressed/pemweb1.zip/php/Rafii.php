<!DOCTYPE html>
<html>
<head>
	<title>Tugas Pemrograman Web</title>
</head>
<body>
<?php
for ($a=5;$a>=1;$a--){
	for ($b=5;$b>=$a;$b--){ 
	 	echo $b;
	 }echo"<br>";
}
?>
<?php
for ($a=1; $a<=5; $a++){
    for ($b=5; $b>=$a; $b--){
        echo $b;
    }echo "<br>";
}
?>
Nama : Mochammad Rafii
NIM : 18.12.0126
</body>
</html>