<!DOCTYPE html>
<html>
<head>
	<title>Tugas Pemrograman web</title>
</head>
<body>
<?php
for ($a=5; $a>=1; $a--){
    for ($b=5; $b>=$a; $b--){
          echo $b;
     }echo "<br>";
}
?>
<?php
for ($a=1; $a<=5; $a++){
    for ($b=5; $b>=$a; $b--){
        echo $b;
    }echo "<br>";
}
?>
<br>
Nama	: Dewa Nicko P.<br>
NIM		: 18.12.0118</br>
</body>
</html>