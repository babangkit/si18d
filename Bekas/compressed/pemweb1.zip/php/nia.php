<?php

  
	   
for ($i=5;$i>=1;$i--) {
	for($j=5;$j>=$i;$j--){
		echo $j;
	}echo "<br>"; 
}
for ($i=2;$i<=5;$i++) {
	for ($k=5;$k>=$i;$k--) {
	     echo $k; 
	 }echo "<br>"; 
}
?>	

18.12.0114_Nia_Alfiani